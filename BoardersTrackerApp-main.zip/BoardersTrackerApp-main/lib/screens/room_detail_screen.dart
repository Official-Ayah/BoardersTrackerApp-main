import 'package:flutter/material.dart';
import 'package:hive/hive.dart';

class RoomDetailScreen extends StatelessWidget {
  final String roomNumber;

  RoomDetailScreen({required this.roomNumber});

  @override
  Widget build(BuildContext context) {
    final boarderBox = Hive.box('boarders'); // Open the boarders box
    final boardersInRoom = boarderBox.values
        .where((boarder) => boarder['room'] == roomNumber)
        .toList();

    return Scaffold(
      appBar: AppBar(
        title: Text('Room $roomNumber Details'),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
      ),
      body: boardersInRoom.isEmpty
          ? Center(
              child: Text(
                'No boarders assigned to this room.',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            )
          : ListView.builder(
              padding: EdgeInsets.all(16),
              itemCount: boardersInRoom.length,
              itemBuilder: (context, index) {
                final boarder = boardersInRoom[index];

                return Card(
                  margin: EdgeInsets.only(bottom: 12),
                  elevation: 4,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  child: ListTile(
                    leading: Icon(Icons.person, color: Colors.deepPurple, size: 30),
                    title: Text(
                      boarder['name'],
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(
                      'Due: ${boarder['dueDate']} | Payment: ${boarder['paymentStatus']}',
                      style: TextStyle(fontSize: 16),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
