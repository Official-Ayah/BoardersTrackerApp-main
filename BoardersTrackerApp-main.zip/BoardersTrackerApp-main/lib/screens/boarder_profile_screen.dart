import 'package:flutter/material.dart';

class BoarderProfileScreen extends StatelessWidget {
  final Map boarder;

  const BoarderProfileScreen({super.key, required this.boarder});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Boarder Profile', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(  // Prevents overflow by allowing scrolling
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Card(
            elevation: 6,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            color: Colors.deepPurple.shade50,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _infoTile(Icons.person, 'Name', boarder['name']),
                  _infoTile(Icons.phone, 'Contact', boarder['contact']),
                  _infoTile(Icons.home, 'Room', boarder['room']),
                  _infoTile(Icons.monetization_on, 'Rent Fee', '₱ ${boarder['rent']}'),
                  _infoTile(Icons.calendar_today, 'Due Date', boarder['dueDate']),
                  _infoTile(Icons.payment, 'Payment Status', boarder['paymentStatus']),
                  _infoTile(Icons.event, 'Move-in Date', boarder['moveInDate']),
                  const SizedBox(height: 10),
                  const Text('Payment History:', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 5),
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(8),
                      boxShadow: [BoxShadow(color: Colors.grey.shade300, blurRadius: 3)],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: boarder['paymentHistory']
                          .map<Widget>((date) => Padding(
                                padding: const EdgeInsets.symmetric(vertical: 4.0),
                                child: Text(date, style: const TextStyle(fontSize: 16)),
                              ))
                          .toList(),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _infoTile(IconData icon, String title, String value) {
    return Column(
      children: [
        ListTile(
          leading: Icon(icon, color: Colors.deepPurple),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text(value, style: const TextStyle(fontSize: 16)),
        ),
        const Divider(),
      ],
    );
  }
}
