import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:intl/intl.dart';

class MonthlySalesDetailScreen extends StatelessWidget {
  final String monthKey;

  MonthlySalesDetailScreen({required this.monthKey});

  @override
  Widget build(BuildContext context) {
    final boarderBox = Hive.box('boarders');

    // Convert month key to DateTime format
    DateTime selectedMonth = DateTime.parse("$monthKey-01");

    // Get boarders who paid in this month
    final payingBoarders = boarderBox.values.where((boarder) {
      List paymentHistory = boarder['paymentHistory'] ?? [];
      return paymentHistory.any((date) {
        DateTime paymentDate = DateFormat('yyyy-MM-dd').parse(date);
        return paymentDate.year == selectedMonth.year && paymentDate.month == selectedMonth.month;
      });
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(DateFormat.yMMMM().format(selectedMonth)), // "March 2025"
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
      ),
      body: payingBoarders.isEmpty
          ? Center(
              child: Text(
                'No boarders made payments this month.',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            )
          : ListView.builder(
              padding: EdgeInsets.all(16),
              itemCount: payingBoarders.length,
              itemBuilder: (context, index) {
                final boarder = payingBoarders[index];

                return Card(
                  margin: EdgeInsets.only(bottom: 12),
                  elevation: 4,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  child: ListTile(
                    leading: Icon(Icons.person, color: Colors.deepPurple, size: 30),
                    title: Text(
                      boarder['name'],
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    subtitle: Text(
                      'Room: ${boarder['room']} | Paid ₱${boarder['rent']}',
                      style: TextStyle(fontSize: 16),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
