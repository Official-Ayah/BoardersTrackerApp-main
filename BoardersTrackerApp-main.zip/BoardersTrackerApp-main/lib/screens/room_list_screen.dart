import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'room_detail_screen.dart';

class RoomListScreen extends StatefulWidget {
  @override
  _RoomListScreenState createState() => _RoomListScreenState();
}

class _RoomListScreenState extends State<RoomListScreen> {
  Future<Box>? _roomBoxFuture;

  @override
  void initState() {
    super.initState();
    _roomBoxFuture = _openRoomBox();
  }

  Future<Box> _openRoomBox() async {
    await Hive.openBox('rooms'); // Ensures the box is open
    await Hive.openBox('boarders'); // Open the boarders box for reference
    return Hive.box('rooms');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Rooms List', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
      ),
      body: FutureBuilder<Box>(
        future: _roomBoxFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.hasError) {
            return const Center(child: Text('Error loading rooms', style: TextStyle(fontSize: 18, color: Colors.red)));
          }

          final roomBox = snapshot.data!;
          return ValueListenableBuilder(
            valueListenable: roomBox.listenable(),
            builder: (context, Box box, _) {
              if (box.isEmpty) {
                return const Center(child: Text('No rooms added', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)));
              }
              return ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: box.length,
                itemBuilder: (context, index) {
                  final room = box.keyAt(index);
                  final status = box.get(room)['status'];
                  final isOccupied = status.toLowerCase() == 'occupied';

                  return Card(
                    elevation: 4,
                    margin: const EdgeInsets.only(bottom: 12),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    color: isOccupied ? Colors.red.shade50 : Colors.green.shade50,
                    child: ListTile(
                      leading: Icon(
                        isOccupied ? Icons.person : Icons.check_circle,
                        color: isOccupied ? Colors.red : Colors.green,
                        size: 30,
                      ),
                      title: Text(
                        'Room $room',
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text(
                        'Status: $status',
                        style: TextStyle(fontSize: 16, color: isOccupied ? Colors.red : Colors.green),
                      ),
                      trailing: Icon(Icons.arrow_forward_ios, color: Colors.grey.shade600),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => RoomDetailScreen(roomNumber: room),
                          ),
                        );
                      },
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}