import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:intl/intl.dart';

class DueBoardersScreen extends StatelessWidget {
  final Box _boarderBox = Hive.box('boarders');

  List<Map> _getDueBoarders(DateTime startDate, DateTime endDate) {
  return _boarderBox.values
      .where((boarder) {
        try {
          DateTime dueDate = DateFormat('yyyy-MM-dd').parse(boarder['dueDate']);
          return boarder['paymentStatus'] == 'Pending' &&
              dueDate.isAfter(DateTime.now().subtract(const Duration(days: 1))) && // Ensure it's in the future
              dueDate.isAfter(startDate.subtract(const Duration(days: 1))) &&
              dueDate.isBefore(endDate);
        } catch (e) {
          return false; // Skip invalid entries
        }
      })
      .toList()
      .cast<Map>();
}


  List<Map> _getPastDueBoarders(DateTime today) {
    return _boarderBox.values
        .where((boarder) {
          try {
            DateTime dueDate = DateFormat('yyyy-MM-dd').parse(boarder['dueDate']);
            return boarder['paymentStatus'] == 'Pending' && dueDate.isBefore(today);
          } catch (e) {
            return false;
          }
        })
        .toList()
        .cast<Map>();
  }

  @override
  Widget build(BuildContext context) {
    DateTime today = DateTime.now();
    DateTime startOfWeek = today.subtract(Duration(days: today.weekday - 1));
    DateTime endOfWeek = startOfWeek.add(const Duration(days: 6));
    DateTime startOfNextWeek = endOfWeek.add(const Duration(days: 1));
    DateTime endOfNextWeek = startOfNextWeek.add(const Duration(days: 6));

    List<Map> pastDue = _getPastDueBoarders(today);
    List<Map> dueToday = _getDueBoarders(today, today.add(const Duration(days: 1)));
    List<Map> dueThisWeek = _getDueBoarders(startOfWeek, endOfWeek);
    List<Map> dueNextWeek = _getDueBoarders(startOfNextWeek, endOfNextWeek);

    Widget _buildSection(String title, List<Map> boarders) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: Row(
              children: [
                Expanded(
                  child: Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                ),
                Container(height: 2, width: 50, color: Colors.deepPurple)
              ],
            ),
          ),
          if (boarders.isEmpty)
            Center(
              child: Text("No due boarders.", style: TextStyle(fontSize: 16, color: Colors.grey[600])),
            ),
          ...boarders.map((boarder) => Card(
                elevation: 4,
                margin: const EdgeInsets.symmetric(vertical: 6),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Colors.deepPurple,
                    child: Icon(Icons.person, color: Colors.white),
                  ),
                  title: Text(boarder['name'], style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.room, size: 18, color: Colors.grey),
                          const SizedBox(width: 5),
                          Text('Room: ${boarder['room']}', style: const TextStyle(color: Colors.black87)),
                        ],
                      ),
                      Row(
                        children: [
                          const Icon(Icons.calendar_today, size: 18, color: Colors.grey),
                          const SizedBox(width: 5),
                          Text('Due: ${boarder['dueDate']}', style: const TextStyle(color: Colors.red)),
                        ],
                      ),
                    ],
                  ),
                  trailing: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: Colors.redAccent,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text("Pending", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                  ),
                ),
              )),
        ],
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Due Boarders', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSection('Past Due', pastDue),
            _buildSection('Due Today', dueToday),
            _buildSection('Due This Week', dueThisWeek),
            _buildSection('Due Next Week', dueNextWeek),
          ],
        ),
      ),
    );
  }
}
