import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:intl/intl.dart';
import 'monthly_sales_detail_screen.dart'; // Import the new screen

class SalesScreen extends StatefulWidget {
  @override
  _SalesScreenState createState() => _SalesScreenState();
}

class _SalesScreenState extends State<SalesScreen> {
  late Future<Box> _salesBoxFuture;

  @override
  void initState() {
    super.initState();
    _salesBoxFuture = Hive.openBox('sales'); // Open Hive box asynchronously
  }

  double _getTotalSales(Box salesBox, DateTime startDate, DateTime endDate) {
    double totalSales = 0.0;

    for (var entry in salesBox.toMap().entries) {
      try {
        DateTime date = DateFormat('yyyy-MM-dd').parse(entry.key);
        if (!date.isBefore(startDate) && !date.isAfter(endDate)) {
          totalSales += (entry.value ?? 0.0);
        }
      } catch (e) {
        continue;
      }
    }
    return totalSales;
  }

  String _formatMonthKey(String key) {
    try {
      if (RegExp(r'^\d{4}-\d{2}$').hasMatch(key)) {
        return DateFormat.yMMMM().format(DateTime.parse("$key-01"));
      }
    } catch (e) {
      return "Invalid Date"; // Handle bad data gracefully
    }
    return key; // Return original key if it doesn't match expected format
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sales Report', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
      ),
      body: FutureBuilder<Box>(
        future: _salesBoxFuture,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          Box salesBox = snapshot.data!;

          DateTime today = DateTime.now();
          DateTime startOfWeek = today.subtract(Duration(days: today.weekday - 1));
          DateTime endOfWeek = startOfWeek.add(const Duration(days: 6));
          DateTime startOfLastWeek = startOfWeek.subtract(const Duration(days: 7));
          DateTime endOfLastWeek = startOfWeek.subtract(const Duration(days: 1));

          double salesToday = _getTotalSales(salesBox, today, today);
          double salesThisWeek = _getTotalSales(salesBox, startOfWeek, endOfWeek);
          double salesLastWeek = _getTotalSales(salesBox, startOfLastWeek, endOfLastWeek);

          Map<String, double> monthlySales = {};
          for (var key in salesBox.keys) {
           try {
           DateTime date = DateFormat('yyyy-MM-dd').parse(key); // Parse full date
           String formattedMonthKey = DateFormat('yyyy-MM').format(date); // Extract "yyyy-MM"

           // Aggregate sales per month
           monthlySales[formattedMonthKey] = (monthlySales[formattedMonthKey] ?? 0.0) + (salesBox.get(key) ?? 0.0);
          } catch (e) {
         continue; // Skip invalid keys
      }
   }


          Widget _buildSalesCard(String title, double amount, IconData icon, Color color) {
            return Card(
              elevation: 4,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: ListTile(
                leading: Icon(icon, size: 40, color: color),
                title: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                subtitle: Text(
                  '₱ ${amount.toStringAsFixed(2)}',
                  style: const TextStyle(fontSize: 16, color: Colors.black87),
                ),
              ),
            );
          }

          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildSalesCard('Sales Today', salesToday, Icons.today, Colors.blue),
                const SizedBox(height: 10),
                _buildSalesCard('Sales This Week', salesThisWeek, Icons.calendar_today, Colors.green),
                const SizedBox(height: 10),
                _buildSalesCard('Sales Last Week', salesLastWeek, Icons.history, Colors.orange),
                const SizedBox(height: 20),
                const Text('Monthly Sales', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                Expanded(
                  child: ListView.builder(
                    itemCount: monthlySales.keys.length,
                    itemBuilder: (context, index) {
                      final key = monthlySales.keys.toList()[index];
                      final sales = monthlySales[key] ?? 0.0;

                      return GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => MonthlySalesDetailScreen(monthKey: key),
                            ),
                          );
                        },
                        child: Card(
                          margin: const EdgeInsets.symmetric(vertical: 6),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                          child: ListTile(
                            leading: const Icon(Icons.bar_chart, color: Colors.deepPurple),
                            title: Text(
                              _formatMonthKey(key),
                              style: const TextStyle(fontWeight: FontWeight.bold),
                            ),
                            subtitle: Text('₱ ${sales.toStringAsFixed(2)}'),
                            trailing: const Icon(Icons.arrow_forward_ios, size: 18, color: Colors.grey),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
