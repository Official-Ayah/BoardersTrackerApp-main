import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/intl.dart';
import 'screens/boarder_profile_screen.dart';
import 'screens/room_list_screen.dart';
import 'screens/due_boarders_screen.dart';
import 'screens/sales_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  await Hive.openBox('boarders');
  await Hive.openBox('rooms');
  await Hive.openBox('sales');
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  MyAppState createState() => MyAppState();
}

class MyAppState extends State<MyApp> {
  bool _isDarkMode = false;

  void _toggleTheme() {
    setState(() {
      _isDarkMode = !_isDarkMode;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Boarding House Tracker',
      theme: _isDarkMode
          ? ThemeData.dark().copyWith(
              primaryColor: Colors.purple,
              colorScheme: ColorScheme.dark().copyWith(
                primary: Colors.purple,
                secondary: Colors.purpleAccent,
              ),
            )
          : ThemeData.light().copyWith(
              primaryColor: Colors.purple,
              colorScheme: ColorScheme.light().copyWith(
                primary: Colors.purple,
                secondary: Colors.purpleAccent,
              ),
            ),
      home: BoarderListScreen(toggleTheme: _toggleTheme, isDarkMode: _isDarkMode),
    );
  }
}

class BoarderListScreen extends StatefulWidget {
  final VoidCallback toggleTheme;
  final bool isDarkMode;
  const BoarderListScreen({required this.toggleTheme, required this.isDarkMode});

  @override
  BoarderListScreenState createState() => BoarderListScreenState();
}

class BoarderListScreenState extends State<BoarderListScreen> {
  final Box _boarderBox = Hive.box('boarders');
  final Box _roomBox = Hive.box('rooms');
  final Box _salesBox = Hive.box('sales');

  TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _searchController.addListener(() {
      setState(() {
        _searchQuery = _searchController.text.toLowerCase();
      });
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
  void _addRoom() {
    showDialog(
      context: context,
      builder: (context) {
        final TextEditingController roomController = TextEditingController();
        return AlertDialog(
          title: Text('Add Room'),
          content: TextField(
            controller: roomController,
            decoration: InputDecoration(
              labelText: 'Room Number',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.meeting_room),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                if (roomController.text.isNotEmpty) {
                  _roomBox.put(roomController.text, {'status': 'Available'});
                  setState(() {});
                }
                Navigator.pop(context);
              },
              child: Text('Save'),
            ),
          ],
        );
      },
    );
  }

  void _addBoarder() {
    showDialog(
      context: context,
      builder: (context) {
        final TextEditingController nameController = TextEditingController();
        final TextEditingController contactController = TextEditingController();
        final TextEditingController rentController = TextEditingController();
        DateTime? selectedDate;
        String? selectedRoom;

        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: Text('Add Boarder'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: nameController,
                      decoration: InputDecoration(
                        labelText: 'Name',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.person),
                      ),
                    ),
                    SizedBox(height: 10),
                    TextField(
                      controller: contactController,
                      decoration: InputDecoration(
                        labelText: 'Contact',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.phone),
                      ),
                    ),
                    SizedBox(height: 10),
                    DropdownButtonFormField<String>(
                      value: selectedRoom,
                      hint: Text('Select Room'),
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.meeting_room),
                      ),
                      items: _roomBox.keys
                          .where((room) => _roomBox.get(room)['status'] == 'Available')
                          .map<DropdownMenuItem<String>>((room) => DropdownMenuItem(
                                value: room.toString(),
                                child: Text(room.toString()),
                              ))
                          .toList(),
                      onChanged: (value) {
                        setState(() {
                          selectedRoom = value;
                        });
                      },
                    ),
                    SizedBox(height: 10),
                    TextField(
                      controller: rentController,
                      decoration: InputDecoration(
                        labelText: 'Rent Fee',
                        prefixText: '₱ ',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.money),
                      ),
                      keyboardType: TextInputType.number,
                    ),
                    SizedBox(height: 10),
                    ListTile(
                      title: Text(selectedDate == null
                          ? 'Select Due Date'
                          : 'Due Date: ${DateFormat('yyyy-MM-dd').format(selectedDate!)}'),
                      trailing: Icon(Icons.calendar_today),
                      onTap: () async {
                        DateTime? pickedDate = await showDatePicker(
                          context: context,
                          initialDate: DateTime.now(),
                          firstDate: DateTime(2000),
                          lastDate: DateTime(2100),
                        );
                        if (pickedDate != null) {
                          setState(() {
                            selectedDate = pickedDate;
                          });
                        }
                      },
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: () {
                    if (selectedRoom != null && selectedDate != null) {
                      _boarderBox.add({
                        'name': nameController.text,
                        'contact': contactController.text,
                        'room': selectedRoom,
                        'rent': rentController.text,
                        'dueDate': DateFormat('yyyy-MM-dd').format(selectedDate!),
                        'paymentStatus': 'Pending',
                        'moveInDate': DateFormat('yyyy-MM-dd').format(DateTime.now()),
                        'paymentHistory': [],
                      });
                      _roomBox.put(selectedRoom, {'status': 'Occupied'});
                      setState(() {});
                    }
                    Navigator.pop(context);
                  },
                  child: Text('Save'),
                ),
              ],
            );
          },
        );
      },
    );
  }

 void _togglePaymentStatus(int index) {
  final boarder = _boarderBox.getAt(index);

  if (boarder['paymentStatus'] == 'Pending') {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Confirm Payment"),
          content: const Text("Are you sure you want to mark this payment as paid?"),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(), 
              child: const Text("Cancel"),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); 

                setState(() {
                  List paymentHistory = List.from(boarder['paymentHistory']);
                  String today = DateFormat('yyyy-MM-dd').format(DateTime.now());

                  // Prevent duplicate payment entry for today
                  if (!paymentHistory.contains(today)) {
                    paymentHistory.add(today);
                    _recordSale(double.parse(boarder['rent']));  // ✅ Stores sales today
                  }

                  _boarderBox.putAt(index, {
                    ...boarder,
                    'paymentStatus': 'Paid',
                    'paymentHistory': paymentHistory,
                  });
                });
              },
              child: const Text("Confirm"),
            ),
          ],
        );
      },
    );
  }
}
void _recordSale(double amount) async {
  final salesBox = await Hive.openBox('sales'); 
  String today = DateFormat('yyyy-MM-dd').format(DateTime.now());  // Ensure correct format

  double currentSales = salesBox.get(today, defaultValue: 0.0);
  salesBox.put(today, currentSales + amount);  // Save correctly formatted date
}

  void _removeBoarder(int index) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Remove Boarder'),
          content: Text('Are you sure you want to remove this boarder?'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                final boarder = _boarderBox.getAt(index);
                final room = boarder['room'];
                _boarderBox.deleteAt(index);
                _roomBox.put(room, {'status': 'Available'});
                setState(() {});
                Navigator.pop(context);
              },
              child: Text('Remove'),
            ),
          ],
        );
      },
    );
  }

 @override
Widget build(BuildContext context) {
  return Scaffold(
    appBar: PreferredSize(
  preferredSize: Size.fromHeight(90.0), // Adjusted height to fit search bar
  child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        titleSpacing: 0,
        title: Row(
          children: [
            SizedBox(width: 5),
            Expanded(
              child: Text(
                'Boarders & Payments',
                style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold, color: Colors.black),
              ),
            ),
            IconButton(
              icon: Icon(widget.isDarkMode ? Icons.light_mode : Icons.dark_mode, color: Colors.black),
              onPressed: widget.toggleTheme,
            ),
          ],
        ),
      ),
      Padding(
        padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 5),
        child: Container(
          height: 24,
          decoration: BoxDecoration(
            color: Colors.grey[200],
            borderRadius: BorderRadius.circular(8.0),
            border: Border.all(color: Colors.grey[400]!),
          ),
          child: TextField(
            decoration: InputDecoration(
              hintText: 'Search...',
              hintStyle: TextStyle(color: Colors.grey[600]),
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            ),
            style: TextStyle(color: Colors.black),
            onChanged: (value) {
              setState(() {
                _searchQuery = value.toLowerCase();
              });
            },
          ),
        ),
      ),
    ],
  ),
),

    drawer: Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: BoxDecoration(color: Colors.deepPurple),
            child: Text(
              'Boarding House Tracker',
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          ListTile(
            leading: Icon(Icons.person_add),
            title: Text('Add Boarder'),
            onTap: _addBoarder,
          ),
          ListTile(
            leading: Icon(Icons.meeting_room),
            title: Text('Add Room'),
            onTap: _addRoom,
          ),
          ListTile(
            leading: Icon(Icons.calendar_today),
            title: Text('Due Boarders'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => DueBoardersScreen()),
              );
            },
          ),
        ],
      ),
    ),
    body: Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.purpleAccent, Colors.deepPurple],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: ValueListenableBuilder(
        valueListenable: _boarderBox.listenable(),
        builder: (context, Box box, _) {
          if (box.isEmpty) {
            return Center(
                child: Text('No boarders added',
                    style: TextStyle(color: Colors.white)));
          }
          final filteredBoarders = box.values.where((boarder) {
            return boarder['name'].toLowerCase().contains(_searchQuery) ||
                boarder['room'].toLowerCase().contains(_searchQuery);
          }).toList();
          return ListView.builder(
            itemCount: filteredBoarders.length,
            itemBuilder: (context, index) {
              final boarder = filteredBoarders[index];
              return Card(
                margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                shape:
                    RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                elevation: 5,
                child: ListTile(
                  contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
                  title: Text(boarder['name'],
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  subtitle:
                      Text('Room: ${boarder['room']} | Due: ${boarder['dueDate']}'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: Icon(
                          boarder['paymentStatus'] == 'Pending'
                          ? Icons.pending
                          : Icons.check_circle,
                        ),
                        onPressed: () => 
                        _togglePaymentStatus(index),
                        ),
                        IconButton(
                          icon: Icon(Icons.exit_to_app, color: Colors.red,),
                          onPressed: () => _removeBoarder(index),
                        ),
                    ],
                  ),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              BoarderProfileScreen(boarder: boarder)),
                    );
                  },
                ),
              );
            },
          );
        },
      ),
    ),
    bottomNavigationBar: BottomNavigationBar(
      items: [
        BottomNavigationBarItem(
          icon: Icon(Icons.attach_money),
          label: 'Sales',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.room),
          label: 'View Rooms',
        ),
      ],
      onTap: (index) {
        if (index == 0) {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => SalesScreen()),
          );
        } else if (index == 1) {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => RoomListScreen()),
          );
        }
      },
    ),
  );
}
}