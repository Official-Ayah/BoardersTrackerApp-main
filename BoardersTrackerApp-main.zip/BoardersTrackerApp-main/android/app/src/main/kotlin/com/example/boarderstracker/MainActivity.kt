package com.example.boarderstracker

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
